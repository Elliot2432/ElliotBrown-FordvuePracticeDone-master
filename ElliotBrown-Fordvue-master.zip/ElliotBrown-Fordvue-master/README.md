# Official Vue.js Documentation
Follow along with the [official documentation for Vue.js](https://vuejs.org/v2/guide/)

## Asynchronous Activities
Asynchronous activities mean you can complete them at your own pace.
